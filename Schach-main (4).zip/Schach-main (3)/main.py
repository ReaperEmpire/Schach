import sys

import pygame
import pygame.color

from buttons import Button
from game import *

pygame.init()

xres = 1200
yres = 800

buttonxres = buttonyres = 100

moveLogxres = 400
moveLogyres = yres

Spielgröße = 8
spielebutton = buttonyres
SPIELFIGUREN = {}

randomListe = [0,1,2,3,4,5,6,7]

BG = pygame.image.load("Chess_wine.jpg")
BG = pygame.transform.scale(BG, (1200, 800))

def figurenimages():
    figuren = ["wB", "wL", "wQ", "wS", "wT", "sB", "sL", "sQ", "sS", "sT", "sK", "wK", "Pr", "Sn", "Ro", "Fs", "Rö"]
    for figur in figuren:
        SPIELFIGUREN[figur] = pygame.transform.scale(pygame.image.load("Spielfiguren/"+figur+".png"), (spielebutton, spielebutton))

def gamesaufbau(Bild, Spiel):
    spielbrett(Bild)
    spielfiguren(Bild, Spiel.spielbrett)

def spielbrett(Bild):
    farben = [pygame.Color("white"), pygame.Color("gray")]
    for r in range(Spielgröße):
        for c in range(Spielgröße):
            farbe = farben[((r+c) % 2)]
            pygame.draw.rect(Bild, farbe, pygame.Rect(c*spielebutton, r*spielebutton, spielebutton, spielebutton))


def spielfiguren(Bild, Spielbrett):
    for r in range(Spielgröße):
        for c in range(Spielgröße):
            figur = Spielbrett[r][c]
            if figur != "-":
                Bild.blit(SPIELFIGUREN[figur], pygame.Rect(c * spielebutton, r * spielebutton, spielebutton, spielebutton))




def getFont(size):
    return pygame.font.Font("font.ttf", size)  # Truetype Font


def mainmenu(Bild, Spiel):
    pygame.display.set_caption("Main Menu")
    while True:
        Bild.blit(BG, (0, 0))
        mausposition = pygame.mouse.get_pos()

        mainmenu_mainTEXT = getFont(50).render("Das ist das Hauptmenu", True, Weiß)
        menutext_Rect = mainmenu_mainTEXT.get_rect(center=(xres / 2, yres / 6))

        Spielemenü_Button = Button(image=pygame.image.load("Mate.png"), x_p=xres / 2, y_p=yres / 2, textinput="Spielemenü", font=getFont(10), basicColor=Weiß, changeColor=Grün, resulution = (160, 160))

        Bild.blit(mainmenu_mainTEXT, menutext_Rect)

        for button in [Spielemenü_Button]:
            button.buttonfarbe(mausposition)
            button.update(Bild=Bild)

        for Eingabe in pygame.event.get():
            if Eingabe.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if Eingabe.type == pygame.MOUSEBUTTONDOWN:
                if Spielemenü_Button.action(mausposition):
                    Spielemenu(Bild=Bild, Spiel=Spiel)
                    break

        pygame.display.update()



def Spielemenu(Bild, Spiel):
    pygame.display.set_caption("Spielemenu")
    while True:
        Bild.fill(Schwarz)

        mausposition = pygame.mouse.get_pos()

        spielemenu_TEXT = getFont(50).render("Das ist das Spielemenu", True, Weiß)
        TEXT_Rect = spielemenu_TEXT.get_rect(center=(xres / 2, yres / 6))

        Bild.blit(spielemenu_TEXT, TEXT_Rect)

        ChaosChess_Button = Button(image=pygame.image.load("Chaos.jpg"), x_p=xres / 2 + 400, y_p=yres / 2, textinput="CC - ChaosChess", font=getFont(10), basicColor=Weiß, changeColor=Grün, resulution = (360, 360))
        QueensChess_Button = Button(image=pygame.image.load("Queen.jpg"), x_p=xres / 2, y_p=yres / 2, textinput="QueensChess", font=getFont(10), basicColor=Weiß, changeColor=Grün, resulution = (360, 360))
        TheFloorIsLava_Button = Button(image=pygame.image.load("Lava.jpg"), x_p=xres / 2 - 400, y_p=yres / 2, textinput="TheFloorIsLava", font=getFont(10), basicColor=Weiß, changeColor=Grün, resulution = (360, 360))

        for button in [ChaosChess_Button, QueensChess_Button, TheFloorIsLava_Button]:
            button.buttonfarbe(mausposition)
            button.update(Bild=Bild)

            for Eingabe in pygame.event.get():
                if Eingabe.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if Eingabe.type == pygame.MOUSEBUTTONDOWN:
                    if ChaosChess_Button.action(mausposition):
                        ChaosChess(Bild, Spiel=Spiel)
                if Eingabe.type == pygame.MOUSEBUTTONDOWN:
                    if QueensChess_Button.action(mausposition):
                        QueensChess(Bild, Spiel=Spiel)
                if Eingabe.type == pygame.MOUSEBUTTONDOWN:
                    if TheFloorIsLava_Button.action(mausposition):
                        TheFloorIsLava(Bild, Spiel=Spiel)
        pygame.display.update()



def ChaosChess(Bild, Spiel):
    pygame.display.set_caption("Spielemenu")
    while True:

        Bild.fill(Grün)
        mausposition = pygame.mouse.get_pos()
        gamesaufbau(Bild=Bild, Spiel=Spiel)
        pygame.display.update()

def QueensChess(Bild, Spiel):

    global runde
    global startspalte, startzeile
    global gespeerteFigur
    gespeerteFigur = ""
    runde = 0
    pygame.display.set_caption("QueensChess")
    figurenimages()
    ausgewählterbutton = ()
    spielerclick = []



    while True:
        mausposition = pygame.mouse.get_pos()
        Bild.fill(Weiß)
        verfügbareZüge = Spiel.machbareZüge()
        zugGemacht = False
        gamesaufbau(Bild=Bild, Spiel=Spiel)


        if Spiel.powerUp1Weis != "":
            powerUp1WeisAbbildung = "Spielfiguren/" + Spiel.powerUp1Weis + ".png"
        else:
            powerUp1WeisAbbildung = "But.png"
        if Spiel.powerUp2Weis != "":
            powerUp2WeisAbbildung = "Spielfiguren/" + Spiel.powerUp2Weis + ".png"
        else:
            powerUp2WeisAbbildung = "But.png"


        if Spiel.powerUp1Schwarz != "":
            powerUp1SchwarzAbbildung = "Spielfiguren/" + Spiel.powerUp1Schwarz + ".png"
        else:
            powerUp1SchwarzAbbildung = "But.png"

        if Spiel.powerUp2Schwarz != "":
            powerUp2SchwarzAbbildung = "Spielfiguren/" + Spiel.powerUp2Schwarz + ".png"
        else:
            powerUp2SchwarzAbbildung = "But.png"


        if Spiel.weisZug:
            PowerUpButton1 = Button(image=pygame.image.load(powerUp1WeisAbbildung), x_p=xres / 2 + 400, y_p=yres / 1.5, textinput="",
                font=getFont(10), basicColor=Weiß, changeColor=Grün, resulution=(100, 100))
            PowerUpButton2 = Button(image=pygame.image.load(powerUp2WeisAbbildung), x_p=xres / 2 + 400, y_p=yres / 2, textinput="",
               font=getFont(10), basicColor=Weiß, changeColor=Grün, resulution=(100, 100))
        else:
            PowerUpButton1 = Button(image=pygame.image.load(powerUp1SchwarzAbbildung), x_p=xres / 2 + 400, y_p=yres / 1.5,
                                    textinput="",
                                    font=getFont(10), basicColor=Weiß, changeColor=Grün, resulution=(100, 100))
            PowerUpButton2 = Button(image=pygame.image.load(powerUp2SchwarzAbbildung), x_p=xres / 2 + 400, y_p=yres / 2,
                                    textinput="",
                                    font=getFont(10), basicColor=Weiß, changeColor=Grün, resulution=(100, 100))

        for button in [PowerUpButton1, PowerUpButton2]:
            button.buttonfarbe(mausposition)
            button.update(Bild=Bild)



        for Eingabe in pygame.event.get():
            if PowerUpButton1.action(mausposition=mausposition):
                # Hier wird Überprüft ob ein PowerUp Button ausgewählt wurde, wenn er nicht ausgewählt wurde aber angeklickt wird wird er auf True Gesetzt
                if Eingabe.type == pygame.MOUSEBUTTONDOWN:
                    if Spiel.powerUp1Status == False:
                        Spiel.powerUp1Status = True
                    else:
                        Spiel.powerUp1Status = False
                #Hier wird das Promote PowerUp Umgesetzt.

                    # Hier wird das erste Weise PowerUp nach Promote Überprüft
                    if Spiel.powerUp1Status and Spiel.weisZug and Spiel.powerUp1Weis == "Pr":
                        while mausposition[0] // spielebutton < 8 and mausposition[1] // spielebutton < 8:
                            zeileS = mausposition[0] // spielebutton
                            spalteS = mausposition[1] // spielebutton
                            if Spiel.spielbrett[spalteS][zeileS][0] == "w" and Spiel.spielbrett[spalteS][zeileS][1] != "K":
                                if Spiel.spielbrett[spalteS][zeileS][1] == "B":  # Bauer wird in Springer Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "S"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "S":  # Springer wird in Läufer Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "L"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "L":  # Läufer wird in einen Turm umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "T"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "T":  # Turm wird in Dame Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "Q"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "Q":  # Dame wird wegen ungültiger Operation in Bauern Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "B"
                    # Hier wird das erste Schwarze PowerUp nach Promote Überprüft
                    if Spiel.powerUp1Status and not Spiel.weisZug and Spiel.powerUp1Schwarz == "Pr":
                        while mausposition[0] // spielebutton < 8 and mausposition[1] // spielebutton < 8:
                            zeileS = mausposition[0] // spielebutton
                            spalteS = mausposition[1] // spielebutton
                            if Spiel.spielbrett[spalteS][zeileS][0] == "s" and Spiel.spielbrett[spalteS][zeileS][1] != "K":
                                if Spiel.spielbrett[spalteS][zeileS][1] == "B":  # Bauer wird in Springer Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "S"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "S":  # Springer wird in Läufer Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "L"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "L":  # Läufer wird in einen Turm umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "T"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "T":  # Turm wird in Dame Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "Q"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "Q":  # Dame wird wegen ungültiger Operation in Bauern Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "B"
                #Hier endet die Promote PowerUp Beschreibung


                #Hier beginnt die Programmierung für das Ragnarök PowerUp
                    # Hier wird das erste PowerUp von Weis kontrolliert
                    if Spiel.powerUp1Status and Spiel.weisZug and Spiel.powerUp1Weis == "Rö":
                        z = random.choice(randomListe)
                        s = random.choice(randomListe)
                        schwarzcounter = 0
                        weiscounter = 0
                        if weiscounter < 4:
                            if Spiel.spielbrett[z][s][0] == "w" and Spiel.spielbrett[z][s][1] != "K":
                                Spiel.spielbrett[z][s] = "-"
                                weiscounter += 1
                        if schwarzcounter < 4:
                            if Spiel.spielbrett[z][s][0] == "s" and Spiel.spielbrett[z][s][1] != "K":
                                Spiel.spielbrett[z][s] = "-"
                                schwarzcounter += 1
                        # Hier wird das PowerUp entfernt
                        if weiscounter == 4 and schwarzcounter == 4:
                            Spiel.powerUp1Status = False
                            Spiel.powerUp1Weis = ""

                    # Hier wird das erste PowerUp von Schwarz kontrolliert
                    if Spiel.powerUp1Status and not Spiel.weisZug and Spiel.powerUp1Schwarz == "Rö":
                        z = random.choice(randomListe)
                        s = random.choice(randomListe)
                        schwarzcounter = 0
                        weiscounter = 0
                        if weiscounter < 4:
                            if Spiel.spielbrett[z][s][0] == "w" and Spiel.spielbrett[z][s][1] != "K":
                                Spiel.spielbrett[z][s] = "-"
                                weiscounter += 1
                        if schwarzcounter < 4:
                            if Spiel.spielbrett[z][s][0] == "s" and Spiel.spielbrett[z][s][1] != "K":
                                Spiel.spielbrett[z][s] = "-"
                                schwarzcounter += 1
                        # Hier wird das PowerUp entfernt
                        if weiscounter == 4 and schwarzcounter == 4:
                            Spiel.powerUp1Status = False
                            Spiel.powerUp1Schwarz = ""
                #Hier endet die Programmierung für das Ragnarök PowerUp


                #Hier beginnt die Programmierung für das Feldsperre PowerUp für den ersten PowerUp-Button
                    if Spiel.powerUp1Status and Spiel.weisZug and Spiel.powerUp1Weis == "Fs":
                        while mausposition[0] // spielebutton < 8 and mausposition[1] // spielebutton < 8:
                            zeileS = mausposition[0] // spielebutton
                            spalteS = mausposition[1] // spielebutton


                            if Spiel.spielbrett[spalteS][zeileS] in Spiel.schwarzeFiguren or Spiel.spielbrett[spalteS][zeileS] in Spiel.weisseFiguren:
                                startzeile = zeileS
                                startspalte = spalteS
                                gespeerteFigur = Spiel.spielbrett[spalteS][zeileS]
                                print("Gesperrte Figur gesetzt")
                                Spiel.powerUp1Status = False
                                Spiel.powerUp1Weis = ""

                    if Spiel.powerUp1Status and not Spiel.weisZug and Spiel.powerUp1Schwarz == "Fs":

                        while mausposition[0] // spielebutton < 8 and mausposition[1] // spielebutton < 8:
                            zeileS = mausposition[0] // spielebutton
                            spalteS = mausposition[1] // spielebutton

                            if Eingabe.type == pygame.MOUSEBUTTONDOWN:
                                 if Spiel.spielbrett[spalteS][zeileS] in Spiel.schwarzeFiguren or Spiel.spielbrett[spalteS][zeileS] in Spiel.weisseFiguren:
                                     startzeile = zeileS
                                     startspalte = spalteS
                                     gespeerteFigur = Spiel.spielbrett[spalteS][zeileS]
                                     Spiel.powerUp1Status = False
                                     Spiel.powerUp1Schwarz = ""
                #Hier endet die Programmierung für das Feldsperre PowerUp













                    print(Spiel.powerUp1Status)
                    print(Spiel.powerUp2Status)





                if PowerUpButton2.action(mausposition=mausposition):
                    if Eingabe.type == pygame.MOUSEBUTTONDOWN:
                        # Hier wird Überprüft ob ein PowerUp Button ausgewählt wurde, wenn er nicht ausgewählt wurde aber angeklickt wird wird er auf True Gesetzt
                        if Spiel.powerUp2Status == False:
                            Spiel.powerUp2Status = True
                        else:
                            Spiel.powerUp2Status = False

                        # Hier wird das Promote PowerUp Umgesetzt.
                        if Spiel.powerUp2Status and Spiel.weisZug and Spiel.powerUp2Weis == "Pr":
                            zeileS = mausposition[0] // spielebutton
                            spalteS = mausposition[1] // spielebutton

                            if Spiel.spielbrett[spalteS][zeileS][0] == "w" and Spiel.spielbrett[spalteS][zeileS][1] != "K":
                                if Spiel.spielbrett[spalteS][zeileS][1] == "B":  # Bauer wird in Springer Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "S"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "S":  # Springer wird in Läufer Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "L"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "L":  # Läufer wird in einen Turm umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "T"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "T":  # Turm wird in Dame Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "Q"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "Q":  # Dame wird wegen ungültiger Operation in Bauern Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "B"

                        if Spiel.powerUp2Status and not Spiel.weisZug and Spiel.powerUp2Schwarz == "Pr":
                            zeileS = mausposition[0] // spielebutton
                            spalteS = mausposition[1] // spielebutton

                            if Spiel.spielbrett[spalteS][zeileS][0] == "s" and Spiel.spielbrett[spalteS][zeileS][1] != "K":
                                if Spiel.spielbrett[spalteS][zeileS][1] == "B":  # Bauer wird in Springer Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "S"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "S":  # Springer wird in Läufer Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "L"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "L":  # Läufer wird in einen Turm umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "T"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "T":  # Turm wird in Dame Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "Q"

                                if Spiel.spielbrett[spalteS][zeileS][1] == "Q":  # Dame wird wegen ungültiger Operation in Bauern Umgewandelt
                                    Spiel.spielbrett[spalteS][zeileS][1] = "B"
                        # Hier endet die Promote PowerUp Beschreibung



                        # Hier beginnt die Programmierung für das Ragnarök PowerUp

                        # Hier wird das zweite PowerUp von Weis kontrolliert
                        if Spiel.powerUp2Status and Spiel.weisZug and Spiel.powerUp2Weis == "Rö":
                            z = random.choice(randomListe)
                            s = random.choice(randomListe)
                            schwarzcounter = 0
                            weiscounter = 0
                            if weiscounter < 4:
                                if Spiel.spielbrett[z][s][0] == "w" and Spiel.spielbrett[z][s][1] != "K":
                                    Spiel.spielbrett[z][s] = "-"
                                    weiscounter += 1
                            if schwarzcounter < 4:
                                if Spiel.spielbrett[z][s][0] == "s" and Spiel.spielbrett[z][s][1] != "K":
                                    Spiel.spielbrett[z][s] = "-"
                                    schwarzcounter += 1
                            # Hier wird das PowerUp entfernt
                            if weiscounter == 4 and schwarzcounter == 4:
                                Spiel.powerUp2Status = False
                                Spiel.powerUp2Weis = ""
                        # Hier wird das zweite PowerUp von Schwarz kontrolliert
                        if Spiel.powerUp2Status and not Spiel.weisZug and Spiel.powerUp2Schwarz == "Rö":
                            z = random.choice(randomListe)
                            s = random.choice(randomListe)
                            schwarzcounter = 0
                            weiscounter = 0
                            if weiscounter < 4:
                                if Spiel.spielbrett[z][s][0] == "w" and Spiel.spielbrett[z][s][1] != "K":
                                    Spiel.spielbrett[z][s] = "-"
                                    weiscounter += 1
                            if schwarzcounter < 4:
                                if Spiel.spielbrett[z][s][0] == "s" and Spiel.spielbrett[z][s][1] != "K":
                                    Spiel.spielbrett[z][s] = "-"
                                    schwarzcounter += 1
                            # Hier wird das PowerUp entfernt
                            if weiscounter == 4 and schwarzcounter == 4:
                                Spiel.powerUp2Status = False
                                Spiel.powerUp2Schwarz = ""

                        # Hier endet die Programmierung für das Ragnarök PowerUp


                        # Hier beginnt die Programmierung für das Feldsperre PowerUp
                        if Spiel.powerUp2Status and Spiel.weisZug and Spiel.powerUp2Weis == "Fs":

                            while mausposition[0] // spielebutton < 8 and mausposition[1] // spielebutton < 8:
                                zeileS = mausposition[0] // spielebutton
                                spalteS = mausposition[1] // spielebutton

                                if Eingabe.type == pygame.MOUSEBUTTONDOWN:
                                    if Spiel.spielbrett[spalteS][zeileS] in Spiel.schwarzeFiguren or \
                                            Spiel.spielbrett[spalteS][zeileS] in Spiel.weisseFiguren:
                                        startzeile = zeileS
                                        startspalte = spalteS
                                        gespeerteFigur = Spiel.spielbrett[spalteS][zeileS]
                                        Spiel.powerUp2Status = False
                                        Spiel.powerUp2Weis = ""

                        if Spiel.powerUp2Status and not Spiel.weisZug and Spiel.powerUp2Schwarz == "Fs":

                            while mausposition[0] // spielebutton < 8 and mausposition[1] // spielebutton < 8:
                                zeileS = mausposition[0] // spielebutton
                                spalteS = mausposition[1] // spielebutton

                                if Eingabe.type == pygame.MOUSEBUTTONDOWN:
                                    if Spiel.spielbrett[spalteS][zeileS] in Spiel.schwarzeFiguren or \
                                            Spiel.spielbrett[spalteS][zeileS] in Spiel.weisseFiguren:
                                        startzeile = zeileS
                                        startspalte = spalteS
                                        gespeerteFigur = Spiel.spielbrett[spalteS][zeileS]
                                        Spiel.powerUp2Status = False
                                        Spiel.powerUp2Schwarz = ""
                        #Hier endet die Programmierung für das Feldsperre PowerUp



                    print(Spiel.powerUp1Status)
                    print(Spiel.powerUp2Status)





            if Eingabe.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if Eingabe.type == pygame.MOUSEBUTTONDOWN:
                mausposition = pygame.mouse.get_pos()
                zeile = mausposition[0] // spielebutton
                spalte = mausposition[1] // spielebutton
                if zeile > 7 or spalte > 7:
                    break
                print(verfügbareZüge)
                if ausgewählterbutton == (zeile, spalte):
                    ausgewählterbutton = ()
                    spielerclick = []
                else:
                    ausgewählterbutton = (zeile, spalte)
                    spielerclick.append(ausgewählterbutton)
                if len(spielerclick) == 2:
                    move = figurenBewegung(spielerclick[0], spielerclick[1], Spiel.spielbrett)

                    if move.figurBewegungID in verfügbareZüge:
                        Spiel.Move(Bild, move)
                        zugGemacht = True
                    ausgewählterbutton = ()
                    spielerclick = []

            if zugGemacht:
                if Spiel.weisZug and gespeerteFigur != "":
                    runde = runde + 1
                if not Spiel.weisZug and gespeerteFigur != "":
                    runde = runde + 1

                if runde == 4 and gespeerteFigur != "":
                    if gespeerteFigur == Spiel.spielbrett[startspalte][startzeile]:
                        Spiel.spielbrett[startspalte][startzeile] = "-"


                zugGemacht = False



        pygame.display.update()

def TheFloorIsLava(Bild, Spiel):
    pygame.display.set_caption("Spielemenu")
    while True:
        Bild.fill(Grün)
        mausposition = pygame.mouse.get_pos()
        gamesaufbau(Bild=Bild, Spiel=Spiel)

        pygame.display.update()

def main():
    pygame.init()
    Bild = pygame.display.set_mode((xres, yres))
    Spiel = Game()
    figurenimages()
    pygame.display.flip()
    mainmenu(Bild=Bild, Spiel=Spiel)
    pygame.draw.rect(Bild, pygame.color("Schwarz"), pygame.rect(xres, xres, moveLogxres, moveLogyres))
    textOrt = moveLogRect(3)
    moveLogFont = pygame.font.SysFont("Arial", 100, False, False)
    Bild.blit(moveLogFont.render([], True, pygame.color("weiß)"), textOrt))

main()
